const express = require("express");

const router = express.Router();

const { compareResume } = require("../controllers/jobController");

const { protect } = require("../middleware/authMiddleware");

router.post("/compare", protect, compareResume);

module.exports = router;